# =========================================================================
# 🐍 LIBRERÍAS ESTÁNDAR
# =========================================================================
import logging

# =========================================================================
# ⚡ DJANGO
# =========================================================================
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Q
from django.shortcuts import render, redirect, get_object_or_404

# =========================================================================
# 🏪 MODELOS
# =========================================================================
from ..models import (
    Producto,
    Categoria,
    ProductoVariante,
    ProductoImagen,
)

# =========================================================================
# 📝 FORMULARIOS
# =========================================================================
from ..forms import ProductoForm

# =========================================================================
# 🧠 SERVICIOS
# =========================================================================
from ..services.producto_service import ProductoService

# =========================================================================
# 📡 LOGGER
# =========================================================================
logger = logging.getLogger(__name__)

# =========================================================================
# 📦 BLOQUE 8: GESTIÓN INTERNA DEL CATÁLOGO (ADMINISTRADOR)
# =========================================================================

@login_required
def mis_productos(request):

    productos = Producto.objects.filter(
        usuario=request.user,activo=True
    ).order_by('-id')

    return render(
        request,
        'mis_productos.html',
        {
            'productos': productos
        }
    )

@login_required
def inventario(request):
    productos_base = Producto.objects.filter(usuario=request.user,activo=True).prefetch_related('variantes').order_by('nombre')

    # 🔍 SISTEMA DE BÚSQUEDA
    q = request.GET.get('q', '').strip()
    if q:
        productos_base = productos_base.filter(nombre__icontains=q)

    total_unidades_fisicas = 0  # 👈 Cambiamos el contador de filas por la suma de unidades
    productos_stock = 0
    stock_bajo = 0
    agotados = 0

    # 🔄 Inyectamos dinámicamente el stock real consolidado a cada objeto fila
    for p in productos_base:
        if p.variantes.exists():
            p.stock_real = p.variantes.aggregate(total=Sum('stock'))['total'] or 0
        else:
            p.stock_real = p.stock or 0

        # Sumamos al total global de unidades en inventario
        total_unidades_fisicas += p.stock_real

        # Clasificación de métricas
        if p.stock_real > 5:
            productos_stock += 1
        elif 0 < p.stock_real <= 5:
            stock_bajo += 1
        else:
            agotados += 1

    context = {
        'productos': productos_base,
        'total_productos': total_unidades_fisicas,  # 👈 Ahora mostrará la suma real (ej: 12 uds)
        'productos_stock': productos_stock,  
        'stock_bajo': stock_bajo,            
        'agotados': agotados,
        'q': q,  
    }
    return render(request, 'inventario.html', context)

@login_required
def lista_productos(request):
    productos = Producto.objects.filter(usuario=request.user).prefetch_related('variantes')
    categorias = Categoria.objects.filter(usuario=request.user)
    return render(request, 'lista_productos.html', {
        'productos': productos,
        'categorias': categorias
    })

@login_required
def crear_categoria(request):
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        if nombre:
            Categoria.objects.create(
                nombre=nombre,
                usuario=request.user
            )
        return redirect('crear_categoria') # Te recarga la misma página para verla en la lista

    categorias = Categoria.objects.filter(usuario=request.user)
    return render(request, 'crear_categoria.html', {'categorias': categorias})

@login_required
def eliminar_categoria(request, categoria_id):
    categoria = get_object_or_404(Categoria, id=categoria_id, usuario=request.user)
    categoria.delete()
    messages.success(request, "Categoría eliminada correctamente.")
    return redirect('dashboard')

@login_required
def guardar_producto_view(request, pk=None):
    """
    Controlador unificado de nivel Enterprise.
    Delega la lógica pesada a ProductoService y gestiona el flujo HTTP y UX.
    """
    perfil = request.user.perfil  # Obtenemos el perfil del usuario actual

    if pk:
        producto = get_object_or_404(Producto, pk=pk, usuario=request.user)
        accion = "actualizado"
    else:
        producto = None  # None indica que es un producto nuevo
        accion = "creado"

        # 🔒 VALIDACIÓN DE LÍMITE DE PLAN (Solo aplica para productos nuevos)
        productos_actuales = Producto.objects.filter(usuario=request.user, activo=True).count()
        if productos_actuales >= perfil.limite_productos:
            messages.warning(
                request, 
                f"⚠️ Has alcanzado el límite de {perfil.limite_productos} productos de tu Plan {perfil.get_plan_display()}. "
                "¡Actualiza tu suscripción para seguir subiendo más joyas!"
            )
            return redirect('gestionar_planes')

    if request.method == 'POST':
        try:
            # 🟢 1. PROCESAR Y BORRAR VARIANTES ELIMINADAS DESDE EL FRONTEND
            # (Solo aplica si el producto ya existe y se están editando sus variantes)
            if producto:
                ids_eliminados = request.POST.get('ids_eliminados', '')
                if ids_eliminados:
                    ids_list = [int(i) for i in ids_eliminados.split(',') if i.isdigit()]
                    # Asegúrate de que el nombre del modelo coincida (ej. VarianteProducto)
                    ProductoVariante.objects.filter(id__in=ids_list, producto=producto).delete()

            # 🚀 2. Continuamos con el guardado habitual del servicio
            producto_guardado = ProductoService.guardar(request, pk=pk) 
            
            messages.success(request, f"¡Producto '{producto_guardado.nombre}' {accion} con éxito rotundo!")
            return redirect('mis_productos')

        except Exception as e:
            logger.error(f"Error crítico en controlador al procesar producto: {str(e)}", exc_info=True)
            messages.error(request, f"⚠️ Error interno: No se guardaron los cambios. Motivo: {str(e)}")
            
            return render(request, 'editar_producto.html', {
                'producto': producto,
                'valores': request.POST,  
                'categorias': Categoria.objects.filter(usuario=request.user)
            })

    # 🔄 Carga por petición GET normal
    valores_iniciales = producto if pk else None

    return render(request, 'editar_producto.html', {
        'producto': producto,
        'valores': valores_iniciales,
        'categorias': Categoria.objects.filter(usuario=request.user)
    })

@login_required
def eliminar_producto(request, id):
    # Uso seguro de get_object_or_404 para evitar el 500 si no existe
    producto = get_object_or_404(Producto, id=id, usuario=request.user)
    
    # Borrado lógico (Soft Delete) para proteger el historial de pedidos y PDFs
    producto.activo = False
    producto.save()
    
    # Opcional: Desactivar también sus variantes
    producto.variantes.update(activo=False)

    return redirect('mis_productos')

@login_required
def eliminar_imagen_producto(request, id):

    producto = get_object_or_404(
        Producto,
        id=id,
        usuario=request.user
    )

    producto.imagen_principal = None
    producto.save()

    return redirect('editar_producto', id=id)

@login_required
def eliminar_imagen_galeria(request, id):

    imagen = get_object_or_404(
        ProductoImagen,
        id=id
    )

    producto_id = imagen.producto.id

    imagen.delete()

    return redirect(
        'editar_producto',
        producto_id
    )