import random
import urllib.parse
import uuid
from decimal import Decimal

from cloudinary.models import CloudinaryField
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.db import models, transaction
from django.db.models import Sum, UniqueConstraint
from django.db.models.signals import post_delete, post_save, pre_save
from django.dispatch import receiver
from django.utils import timezone
from django.utils.text import slugify

# =========================================================================
# ⚙️ CENTRO DE CONTROL DE TARIFAS DEL SAAS
# =========================================================================
PRECIOS_PLANES = {
    'basico': {
        'nombre': 'Básico',
        'precio_mensual': Decimal('49900.00'),  # COP
        'descripcion': 'Todo lo esencial para comenzar.',
        'link_pago': 'https://checkout.wompi.co/l/TU_LINK_BASICO'
    },
    'semi': {
        'nombre': 'Semi',
        'precio_mensual': Decimal('89900.00'),  # COP
        'descripcion': 'Control avanzado y facturación Siigo.',
        'link_pago': 'https://checkout.wompi.co/l/TU_LINK_SEMI'
    },
    'premium': {
        'nombre': 'Premium',
        'precio_mensual': Decimal('149900.00'),  # COP
        'descripcion': 'Subdominio personalizado exclusivo + CRM completo, automatizaciones de WhatsApp y soporte prioritario 24/7.',
        'link_pago': 'https://checkout.wompi.co/l/TU_LINK_PREMIUM'
    }
}

class Perfil(models.Model):
    PLANES = [
        ('basico', 'Básico'),
        ('semi', 'Semi'),
        ('premium', 'Premium'),
    ]
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name='perfil'
    )
    # EMPRESA
    nombre_tienda = models.CharField(max_length=120)
    # 🌐 SUBDOMINIO SAAS (Agregado para arquitectura multi-tenant)
    subdominio = models.CharField(
        max_length=50, 
        unique=True, 
        blank=True, 
        null=True, 
        db_index=True,
        verbose_name="Subdominio SaaS",
        help_text="Ejemplo: 'tuluna' para tuluna.joyasapp.com"
    )
    banner = models.ImageField(upload_to='banners/', blank=True, null=True)
    banner_texto = models.TextField(blank=True, default="")
    logo = models.ImageField(upload_to='logos/', blank=True, null=True)
    color_primario = models.CharField(max_length=7, default="#122216")
    color_secundario = models.CharField(max_length=7, default='#000000')

    # CONTACTO
    whatsapp = models.CharField(max_length=20, blank=True, null=True)
    email_empresa = models.EmailField(blank=True, null=True)

    # DIRECCIÓN
    direccion = models.CharField(max_length=200, blank=True, null=True)
    ciudad = models.CharField(max_length=100, blank=True, null=True)

    # REDES
    instagram = models.CharField(max_length=150, blank=True, null=True)
    facebook = models.CharField(max_length=150, blank=True, null=True)
    tiktok = models.CharField(max_length=150, blank=True, null=True)

    # FACTURACIÓN
    nit = models.CharField(max_length=50, blank=True, null=True, verbose_name="NIT")

    # PLAN SaaS
    plan = models.CharField(max_length=20, choices=PLANES, default='basico')
    activa = models.BooleanField(default=True)
    plan_vence = models.DateField(default=timezone.localdate)

    # DISEÑO
    color_principal = models.CharField(max_length=20, default="#000000", verbose_name="Color principal")
    fecha_creacion = models.DateTimeField(auto_now_add=True)

    # 🔒 Identificador único y seguro para el Webhook del SaaS
    webhook_uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True, verbose_name="Webhook UUID")

    # 💳 PASARELAS DE PAGO INDEPENDIENTES (SAAS)
    wompi_public_key = models.CharField(max_length=255, blank=True, null=True, verbose_name="Wompi Public Key")
    mercadopago_access_token = models.CharField(max_length=255, blank=True, null=True, verbose_name="Mercado Pago Access Token")
    
    # 🚚 CONFIGURACIÓN DE ENVÍOS 
    costo_envio_estandar = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'), verbose_name="Costo de Envío")

    # ⚖️ CONFIGURACIÓN TRIBUTARIA
    responsable_iva = models.BooleanField(default=False, verbose_name="¿Es Responsable de IVA?")
    porcentaje_iva = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('19.00'), verbose_name="Porcentaje de IVA (%)")
    mostrar_iva_discriminado = models.BooleanField(default=True, verbose_name="Mostrar IVA Discriminado en Factura")
    
    # Conexiones DIAN y Facturación Electrónica (Hitos para Siigo)
    prefijo_factura = models.CharField(max_length=10, blank=True, null=True, verbose_name="Prefijo de Facturación")
    consecutivo_actual = models.IntegerField(default=1, verbose_name="Siguiente Consecutivo")
    resolucion_dian = models.TextField(blank=True, null=True, verbose_name="Resolución DIAN")
    integracion_siigo_activa = models.BooleanField(default=False, verbose_name="Activar Sincronización con Siigo")

    # 🎁 CAMPAÑAS Y DESCUENTOS EN PROMO
    aplicar_descuentos = models.BooleanField(default=False, verbose_name="Activar Descuentos por Campaña / Temporada")
    porcentaje_descuento_promo = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('0.00'), verbose_name="Porcentaje Descuento Promoción (%)")

    # 🚚 CONTROL DE ENVÍOS AVANZADO
    cobrar_envio = models.BooleanField(default=False, verbose_name="¿Cobrar Envío?")
    envio_gratis_desde = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True, verbose_name="Envío Gratis desde Monto")

    @property
    def get_precio_plan(self):
        """Devuelve el costo mensual del plan actual del perfil."""
        plan_info = PRECIOS_PLANES.get(self.plan, PRECIOS_PLANES['basico'])
        return plan_info['precio_mensual']

    def __str__(self):
        return f"{self.user.username} - {self.nombre_tienda} ({self.subdominio or 'Sin subdominio'})"
class ConfiguracionEmpresa(models.Model):
    class TipoEnvio(models.TextChoices):
        RECOGIDA = 'recogida', 'Recogida en tienda (Sin costo)'
        ESTANDAR = 'estandar', 'Envío Estándar / Transportadora'
        PERSONALIZADO = 'personalizado', 'Tarifa Especial / Manual'

    perfil = models.OneToOneField('Perfil', on_delete=models.CASCADE, related_name='configuracion_fiscal')
    
    # 🏛️ Reglas Fiscales Dinámicas
    responsable_iva = models.BooleanField(default=False)
    porcentaje_iva = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('19.00'))
    mostrar_iva_discriminado = models.BooleanField(default=False)
    
    es_retenedor = models.BooleanField(default=False)
    porcentaje_retefuente = models.DecimalField(
        max_digits=5, 
        decimal_places=2, 
        default=Decimal('2.50'),
        help_text="Porcentaje de retención en la fuente (ej. 2.50 o 3.50)"
    )
    
    # 🚚 Reglas de Logística y Descuentos
    cobrar_envio = models.BooleanField(default=False)
    costo_envio_estandar = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    envio_gratis_desde = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    
    aplicar_descuentos = models.BooleanField(default=False)
    porcentaje_descuento_promo = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('0.00'))

    def __str__(self):
        return f"Configuración Fiscal - {self.perfil.nombre_tienda}"


class Categoria(models.Model):
    nombre = models.CharField(max_length=100)
    usuario = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )

    def __str__(self):
        return self.nombre


class Producto(models.Model):
    # --- Campos Base ---
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    nombre = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, blank=True, null=True)
    referencia = models.CharField(max_length=50, blank=True, null=True, verbose_name="SKU")
    descripcion = models.TextField()
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE)
    destacado = models.BooleanField(default=False)
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    stock = models.PositiveIntegerField(default=0)
    color = models.CharField(max_length=50, null=True, blank=True)
    talla = models.CharField(max_length=50, null=True, blank=True)
    colores_disponibles = models.JSONField(default=list, blank=True)
    tallas_disponibles = models.JSONField(default=list, blank=True)
    imagen_principal = CloudinaryField('imagen', blank=True, null=True)
    video = models.FileField(upload_to='productos/videos/', blank=True, null=True)
    certificado = models.FileField(upload_to='certificados/', blank=True, null=True)
    
    # --- Configuración de Venta ---
    tipo_venta = models.CharField(max_length=20, choices=[('unidad', 'Por unidad'), ('gramo', 'Por gramos')], default='unidad')
    peso_producto = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True, help_text="Peso del producto en gramos")
    cantidad_mayorista = models.IntegerField(default=6)

    # --- Precios Base (Costo y Unidad) ---
    precio_costo = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'), verbose_name="Precio de costo")
    precio_detal = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    precio_semimayor = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    precio_mayor = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    
    # --- Precios por Gramo ---
    precio_por_gramo_detal = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    precio_por_gramo_semimayor = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    precio_por_gramo_mayor = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    activo = models.BooleanField(default=True)

    # =======================================================================
    # 📊 MOTORES DE CÁLCULO DINÁMICO
    # =======================================================================
    @property
    def precio_calculado_detal(self):
        if self.tipo_venta == 'gramo':
            return Decimal(str(self.precio_por_gramo_detal or 0)) * Decimal(str(self.peso_producto or 0))
        return Decimal(str(self.precio_detal or 0))
    
    @property
    def precio_calculado_semimayor(self):
        if self.tipo_venta == 'gramo':
            return Decimal(str(self.precio_por_gramo_semimayor or 0)) * Decimal(str(self.peso_producto or 0))
        return Decimal(str(self.precio_semimayor or 0))

    @property
    def precio_calculado_mayor(self):
        if self.tipo_venta == 'gramo':
            return Decimal(str(self.precio_por_gramo_mayor or 0)) * Decimal(str(self.peso_producto or 0))
        return Decimal(str(self.precio_mayor or 0))

    # Aliases
    @property
    def precio_total_detal_dinamico(self): return self.precio_calculado_detal
    @property
    def precio_total_semimayor_dinamico(self): return self.precio_calculado_semimayor
    @property
    def precio_total_mayor_dinamico(self): return self.precio_calculado_mayor

    # =======================================================================
    # 📈 INDICADORES DE RENTABILIDAD
    # =======================================================================
    @property
    def utilidad_detal(self):
        return self.precio_calculado_detal - Decimal(str(self.precio_costo or 0))

    @property
    def utilidad_semimayor(self):
        return self.precio_calculado_semimayor - Decimal(str(self.precio_costo or 0))

    @property
    def utilidad_mayor(self):
        return self.precio_calculado_mayor - Decimal(str(self.precio_costo or 0))
    
    @property
    def stock_total(self):
        if self.variantes.exists():
            return sum(v.stock for v in self.variantes.all())
        return self.stock

    # =======================================================================
    # 🔥 LÓGICA CENTRAL DE ESCALAS
    # =======================================================================
    def precio_por_cantidad(self, cantidad):
        if self.tipo_venta == 'gramo':
            if not self.peso_producto:
                return Decimal('0.00')

            total_gramos = Decimal(str(cantidad)) * Decimal(str(self.peso_producto))

            if total_gramos >= 12:
                precio_gramo = self.precio_por_gramo_mayor or 0
            elif total_gramos >= 6:
                precio_gramo = self.precio_por_gramo_semimayor or 0
            else:
                precio_gramo = self.precio_por_gramo_detal or 0
            
            return Decimal(str(self.peso_producto)) * Decimal(str(precio_gramo))
        else:
            if cantidad >= 12:
                precio_unidad = self.precio_mayor or self.precio_detal or 0
            elif cantidad >= 6:
                precio_unidad = self.precio_semimayor or self.precio_detal or 0
            else:
                precio_unidad = self.precio_detal or 0
            return Decimal(str(precio_unidad))

    def __str__(self):
        return self.nombre

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['usuario', 'referencia'], name='unique_referencia_por_usuario'),
            models.UniqueConstraint(fields=['usuario', 'slug'], name='unique_slug_por_usuario'),
        ]

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.nombre)
            slug = base_slug
            contador = 1
            while Producto.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base_slug}-{contador}"
                contador += 1
            self.slug = slug
        super().save(*args, **kwargs)

        # Si NO tiene variantes, aseguramos que el stock principal mande. 
        # Si TIENE variantes, el stock principal puede ser la suma de ellas opcionalmente.
        if self.variantes.exists():
            total_var = self.variantes.aggregate(total=Sum('stock'))['total'] or 0
            if self.stock != total_var:
                Producto.objects.filter(pk=self.pk).update(stock=total_var)

class ProductoImagen(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name='imagenes')
    imagen = CloudinaryField('imagen', blank=True, null=True)

    def __str__(self):
        return f"Imagen de {self.producto.nombre}"


class ProductoVariante(models.Model):
    producto = models.ForeignKey(
        Producto,
        on_delete=models.CASCADE,
        related_name='variantes'
    )
    
    color = models.CharField(max_length=100, null=True, blank=True)
    talla = models.CharField(max_length=50, null=True, blank=True)
    stock = models.PositiveIntegerField(default=0)
    precio_venta = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'), blank=True, null=True)

    @property
    def precio_total_dinamico(self):
        if self.producto.tipo_venta == 'gramo':
            return (self.precio_venta or Decimal('0.00')) * (self.peso or Decimal('0.00'))
        return self.precio_venta or Decimal('0.00')
    
    peso = models.DecimalField(max_digits=6, decimal_places=2, default=Decimal('0.00'), blank=True, null=True)
    codigo = models.CharField(max_length=50, blank=True, null=True)
    activo = models.BooleanField(default=True)
    foto = CloudinaryField('imagen_variante', blank=True, null=True) 

    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['producto', 'color', 'talla'], name='unique_variante_producto_color_talla')
        ]

    def __str__(self):
        return f"{self.producto.nombre} | {self.color or 'U'}-{self.talla or 'U'} | ${self.precio_venta} ({self.stock} unds)"


class CarritoItem(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    variante = models.ForeignKey(ProductoVariante, null=True, blank=True, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)
    session_key = models.CharField(max_length=40)
    fecha_creacion = models.DateTimeField(default=timezone.now)
    color = models.CharField(max_length=50, null=True, blank=True)
    talla = models.CharField(max_length=50, null=True, blank=True)

    def precio_aplicado(self):
        tipo = getattr(self, '_tipo_global', None)
        if not tipo:
            if self.cantidad >= 12: 
                tipo = "Mayorista"
            elif self.cantidad >= 6: 
                tipo = "Semi-Mayorista"
            else: 
                tipo = "Detal"

        if self.producto.tipo_venta == 'gramo':
            if tipo == "Mayorista":
                precio = self.producto.precio_por_gramo_mayor
            elif tipo == "Semi-Mayorista":
                precio = self.producto.precio_por_gramo_semimayor
            else:
                precio = self.producto.precio_por_gramo_detal
            
            return Decimal(str(precio or self.producto.precio_por_gramo_detal or 0))
        
        else:
            if tipo == "Mayorista":
                precio = self.producto.precio_mayor
            elif tipo == "Semi-Mayorista":
                precio = self.producto.precio_semimayor
            else:
                precio = self.producto.precio_detal
                
            return Decimal(str(precio or self.producto.precio_detal or 0))
    
    def precio_unitario_articulo(self):
        precio_base = self.precio_aplicado()
        if self.producto.tipo_venta == 'gramo':
            return Decimal(str(self.producto.peso_producto or 0)) * precio_base
        return precio_base

    def subtotal(self):
        precio_uni = self.precio_aplicado()
        cantidad_val = Decimal(str(self.cantidad or 1))

        if self.producto.tipo_venta == 'gramo':
            peso_val = Decimal(str(self.producto.peso_producto or 0))
            total_gramos = cantidad_val * peso_val
            return total_gramos * precio_uni

        return cantidad_val * precio_uni

    def ahorro(self):
        precio_act = self.precio_aplicado()
        cantidad_val = Decimal(str(self.cantidad or 1))

        if self.producto.tipo_venta == 'gramo':
            peso_val = Decimal(str(self.producto.peso_producto or 0))
            total_gramos = cantidad_val * peso_val
            precio_or = Decimal(str(self.producto.precio_por_gramo_detal or 0))
            return (precio_or - precio_act) * total_gramos

        precio_or = Decimal(str(self.producto.precio_detal or 0))
        return (precio_or - precio_act) * cantidad_val

    def __str__(self):
        return f"{self.cantidad} x {self.producto.nombre}"


class Cliente(models.Model):
    # 🏢 AISLAMIENTO SAAS (Multi-tenant)
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    
    # 👤 DATOS BÁSICOS
    nombre = models.CharField(max_length=100)
    nit = models.CharField(max_length=50, blank=True, null=True)
    telefono = models.CharField(max_length=20, unique=True)
    email = models.EmailField(blank=True, null=True)
    ciudad = models.CharField(max_length=100, blank=True, null=True)
    direccion = models.CharField(max_length=255, blank=True, null=True)
    fecha_cumpleanos = models.DateField(blank=True, null=True)
    observaciones = models.TextField(blank=True)
    etiquetas = models.CharField(max_length=300, blank=True, help_text="Ej: Novias, Mayorista, Plata")
    
    # 🏢 CRM COLABORATIVO
    asesor = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        related_name="clientes_asignados"
    )

    # 🔒 PRIVACIDAD Y SEGUIMIENTO
    acepta_whatsapp = models.BooleanField(default=True)
    activo = models.BooleanField(default=True)

    # 💎 CLASIFICACIÓN
    tipo_cliente = models.CharField(
        max_length=20,
        choices=[
            ('detalle', 'Detal'),
            ('vip', 'VIP'),
            ('mayorista', 'Mayorista'),
            ('distribuidor', 'Distribuidor'),
        ],
        default='detalle'
    )
    porcentaje_descuento = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('0.00'))

    # 📈 SEGMENTACIÓN CRM AVANZADA
    origen = models.CharField(
        max_length=30,
        default="WhatsApp",
        choices=[
            ("WhatsApp", "WhatsApp"),
            ("Tienda", "Tienda"),
            ("Instagram", "Instagram"),
            ("Facebook", "Facebook"),
            ("TikTok", "TikTok"),
            ("Página Web", "Página Web"),
        ]
    )
    
    estado = models.CharField(
        max_length=20,
        default="Nuevo",
        choices=[
            ("Nuevo", "Nuevo"),
            ("Activo", "Activo"),
            ("Frecuente", "Frecuente"),
            ("VIP", "VIP"),
            ("Inactivo", "Inactivo"),
        ]
    )
    
    nivel = models.CharField(
        max_length=20,
        default="Bronce",
        choices=[
            ("Bronce", "Bronce"),
            ("Plata", "Plata"),
            ("Oro", "Oro"),
            ("Diamante", "Diamante"),
        ]
    )

    # 📊 METRICAS FINANCIERAS
    total_compras = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    saldo_pendiente = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    numero_pedidos = models.IntegerField(default=0)
    ultima_compra = models.DateTimeField(null=True, blank=True)
    
    # 🎯 PREFERENCIAS DE CONSUMO
    categoria_favorita = models.CharField(max_length=100, blank=True, null=True)
    variante_favorita_resumen = models.CharField(max_length=150, blank=True, null=True)
    
    # 🔄 RETENCIÓN
    ultima_categoria = models.CharField(max_length=100, blank=True, null=True)
    ultima_variante = models.CharField(max_length=150, blank=True, null=True)
    ultima_factura = models.CharField(max_length=40, blank=True, null=True)
    dias_sin_comprar = models.IntegerField(default=0)
    ultimo_contacto = models.DateTimeField(blank=True, null=True)
    proxima_tarea = models.DateTimeField(blank=True, null=True)

    fecha_creacion = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"[{self.nivel}] {self.nombre} - {self.telefono}"
        
    @property
    def ticket_promedio(self):
        if self.numero_pedidos > 0:
            return self.total_compras / self.numero_pedidos
        return Decimal('0.00')

    def actualizar_ciclo_y_rangos(self):
        if self.ultima_compra:
            delta = timezone.now() - self.ultima_compra
            self.dias_sin_comprar = delta.days
            if self.dias_sin_comprar > 90:
                self.estado = "Inactivo"
        else:
            self.dias_sin_comprar = 0

        if self.total_compras >= 5000000 or self.numero_pedidos >= 20:
            self.nivel = "Diamante"
            self.estado = "VIP"
            self.tipo_cliente = "vip"
        elif self.total_compras >= 3000000 or self.numero_pedidos >= 10:
            self.nivel = "Oro"
            if self.dias_sin_comprar <= 90: 
                self.estado = "Frecuente"
        elif self.total_compras >= 1000000 or self.numero_pedidos >= 5:
            self.nivel = "Plata"
            if self.dias_sin_comprar <= 90: 
                self.estado = "Activo"
        else:
            self.nivel = "Bronce"
            if self.numero_pedidos == 1: 
                self.estado = "Nuevo"

    # === 📱 AUTOMATIZACIÓN DE WHATSAPP ===
    
    @property
    def link_whatsapp_cumpleanos(self):
        try:
            nombre_negocio = self.usuario.perfil.nombre_tienda
        except AttributeError:
            nombre_negocio = "nuestra joyería"
            
        if not nombre_negocio:
            nombre_negocio = "nuestra joyería"
        
        texto = (
            f"¡Hola, {self.nombre}! 🌟 De parte de todo el equipo de {nombre_negocio}, "
            f"te deseamos un espectacular feliz cumpleaños. 🎂 En tu día, queremos "
            f"celebrarte con un obsequio especial: un 10% de descuento en tu próxima "
            f"joya favorita. 💎 ¡Que pases un día maravilloso!"
        )
        return f"https://wa.me/{self.telefono}?text={urllib.parse.quote(texto)}"

    @property
    def link_whatsapp_saldo(self):
        try:
            nombre_negocio = self.usuario.perfil.nombre_tienda
        except AttributeError:
            nombre_negocio = "nuestra joyería"
            
        if not nombre_negocio:
            nombre_negocio = "nuestra joyería"
        
        texto = (
            f"Hola, {self.nombre}. ✨ Esperamos que estés muy bien. Nos comunicamos de "
            f"{nombre_negocio} para actualizar tu estado de cuenta. Actualmente presentas "
            f"un saldo pendiente de ${self.saldo_pendiente:,.0f}. 📝 Si deseas realizar el pago "
            f"por transferencia o reportar tu comprobante, quedamos atentos por este medio. "
            f"¡Muchas gracias por tu confianza!"
        )
        return f"https://wa.me/{self.telefono}?text={urllib.parse.quote(texto)}"

    @property
    def link_whatsapp_inactivo(self):
        try:
            nombre_negocio = self.usuario.perfil.nombre_tienda
        except AttributeError:
            nombre_negocio = "nuestra joyería"
            
        if not nombre_negocio:
            nombre_negocio = "nuestra joyería"
        
        texto = (
            f"¡Hola, {self.nombre}! 🥰 Hace tiempo que no sabemos de ti en {nombre_negocio} "
            f"y te extrañamos. Nos acaban de llegar unas piezas hermosas en nuestra última "
            f"colección que van perfectas con tu estilo. ✨ Te dejamos un envío gratis "
            f"válido por esta semana si deseas consentirte de nuevo. ¡Un abrazo!"
        )
        return f"https://wa.me/{self.telefono}?text={urllib.parse.quote(texto)}"


class Pedido(models.Model):
    # 🔹 IDENTIFICACIÓN
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    tienda = models.ForeignKey(Perfil, on_delete=models.CASCADE, null=True, blank=True)
    numero_orden = models.CharField(max_length=20, unique=True)
    token_publico = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    fecha = models.DateTimeField(auto_now_add=True)
    cliente = models.ForeignKey('Cliente', on_delete=models.SET_NULL, null=True, blank=True, related_name='pedidos')

    # 🔹 CLIENTE
    cliente_nombre = models.CharField(max_length=100, blank=True, null=True)
    cliente_nit = models.CharField(max_length=50, blank=True, null=True)
    cliente_direccion = models.CharField(max_length=200, blank=True, null=True)
    cliente_telefono = models.CharField(max_length=20, blank=True, null=True)
    cliente_email = models.EmailField(blank=True, null=True)
    cliente_ciudad = models.CharField(max_length=100, blank=True, null=True)

    # 🔹 ESTADO Y TIPO
    ESTADOS = [('pendiente', 'Pendiente'), ('pagado', 'Pagado'), ('enviado', 'Enviado'), ('vencido', 'Vencido')]
    estado = models.CharField(max_length=20, choices=ESTADOS, default='pendiente')
    es_credito = models.BooleanField(default=False)
    TIPO_PAGO = (('contado', 'Contado'), ('credito', 'Crédito'))
    tipo_pago = models.CharField(max_length=10, choices=TIPO_PAGO, default='contado')
    saldo_pendiente = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    fecha_limite = models.DateField(null=True, blank=True)
    fecha_pago = models.DateField(null=True, blank=True)

    # 🔍 AUDITORÍA Y PASARELAS
    mercadopago_payment_id = models.CharField(max_length=100, blank=True, null=True, verbose_name="ID Pago Mercado Pago")
    wompi_transaction_id = models.CharField(max_length=100, blank=True, null=True, verbose_name="ID Transacción Wompi")

    # 🔹 IMPUESTOS Y DESCUENTOS
    aplica_iva = models.BooleanField(default=False)
    es_retenedor = models.BooleanField(default=False)
    iva = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    retefuente = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    descuento_total = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    porcentaje_descuento = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('0.00'))
    tipo_envio = models.CharField(
        max_length=20,
        choices=[('recogida', 'Recogida en tienda'), ('domicilio', 'Domicilio'), ('transportadora', 'Transportadora')],
        default='recogida'
    )
    costo_envio = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    direccion_envio = models.CharField(max_length=255, blank=True, null=True)
    ciudad_envio = models.CharField(max_length=100, blank=True, null=True)

    # 🔹 TOTAL Y COSTOS
    total = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    costo_material = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))
    costo_mano_obra = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))

    @property
    def utilidad(self):
        return self.total - (self.costo_material + self.costo_mano_obra)
    
    @property
    def costo_total(self):
        return self.costo_material + self.costo_mano_obra
    
    @property
    def total_limpio(self):
        return int(self.total)
    
    @property
    def subtotal_antes_de_descuento(self):
        return sum(item.subtotal for item in self.items.all())

    @property
    def subtotal_neto(self):
        return self.subtotal_antes_de_descuento - self.descuento_total

    def __str__(self):
        return self.numero_orden

    def sincronizar_pedido(self):
        """PUNTO ÚNICO DE VERDAD FINANCIERA"""
        with transaction.atomic():
            items_relacionados = self.items.select_related('producto').all()
            
            subtotal_items = sum(item.subtotal for item in items_relacionados)
            descuento_items = sum(item.descuento for item in items_relacionados)
            iva_items = sum(item.iva for item in items_relacionados)
            
            self.costo_material = sum(Decimal(str(item.producto.precio_costo or 0)) * item.cantidad for item in items_relacionados)
            envio = Decimal(str(getattr(self, 'costo_envio', 0) or 0))
            
            self.total = subtotal_items + iva_items + envio - descuento_items
            self.descuento_total = descuento_items

            if getattr(self, 'tipo_pago', 'contado') == 'credito' or getattr(self, 'es_credito', False):
                total_abonos = self.abonos.aggregate(suma=Sum('monto'))['suma'] or Decimal('0.00')
                self.saldo_pendiente = max(Decimal('0.00'), self.total - total_abonos)
                
                if getattr(self, 'cliente', None):
                    self.cliente.saldo_pendiente = self.saldo_pendiente
                    self.cliente.save(update_fields=['saldo_pendiente'])
            else:
                self.saldo_pendiente = Decimal('0.00')

            self.save(update_fields=['total', 'costo_material', 'descuento_total', 'saldo_pendiente'])


class Abono(models.Model):
    pedido = models.ForeignKey(
        Pedido,
        on_delete=models.CASCADE,
        related_name='abonos'
    )
    monto = models.DecimalField(max_digits=10, decimal_places=2)
    fecha = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"Abono {self.monto} - Pedido {self.pedido.numero_orden}"

    def save(self, *args, **kwargs):
        with transaction.atomic():
            super().save(*args, **kwargs)
            self.pedido.sincronizar_pedido()

    def delete(self, *args, **kwargs):
        with transaction.atomic():
            pedido_padre = self.pedido
            super().delete(*args, **kwargs)
            pedido_padre.sincronizar_pedido()


class PedidoItem(models.Model):
    usuario = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )
    pedido = models.ForeignKey(Pedido, on_delete=models.CASCADE, related_name='items')
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    variante = models.ForeignKey(ProductoVariante, null=True, blank=True, on_delete=models.SET_NULL)
    cantidad = models.PositiveIntegerField()
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    descuento = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('0.00'))
    iva = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    retefuente = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))  
    total_final = models.DecimalField(max_digits=12, decimal_places=2, default=Decimal('0.00'))
    total_gramos = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal('0.00'))

    def calcular_subtotal(self):
        if self.producto.tipo_venta == 'gramo':
            peso_unitario = Decimal(str(self.producto.peso_producto or 0))
            self.total_gramos = Decimal(str(self.cantidad)) * peso_unitario
            return self.total_gramos * self.precio
        
        self.total_gramos = Decimal('0.00')
        return self.cantidad * self.precio  

    def save(self, *args, **kwargs):
        self.subtotal = Decimal(str(self.calcular_subtotal() or 0))
        
        if getattr(self.pedido, 'aplica_iva', False):
            self.iva = self.subtotal * Decimal('0.19')
        else:
            self.iva = Decimal('0.00')

        descuento = Decimal(str(getattr(self, 'descuento', 0) or 0))
        self.total_final = self.subtotal + self.iva - descuento
        
        # Validación de stock previa a la escritura en DB
        if self.variante and self.variante.stock < self.cantidad:
            raise ValidationError(f"No hay stock suficiente. Disponibles: {self.variante.stock} unidades de esta variante.")
        elif not self.variante and self.producto.stock < self.cantidad:
            raise ValidationError(f"No hay stock suficiente. Disponibles: {self.producto.stock} unidades de este producto.")

        super().save(*args, **kwargs)

class Gasto(models.Model):
    # Relación directa con el Perfil (la tienda o tenant activo)
    perfil = models.ForeignKey(Perfil, on_delete=models.CASCADE, related_name='gastos', verbose_name="Tienda / Perfil")
    
    # Opcional: Si quieres saber qué usuario exacto creó el registro
    usuario = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Registrado por")
    
    nombre = models.CharField(max_length=150)
    monto = models.DecimalField(max_digits=12, decimal_places=2)
    categoria = models.CharField(max_length=50, default='fabricacion')
    observaciones = models.TextField(null=True, blank=True)
    fecha = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.nombre} - ${self.monto} ({self.perfil.nombre_tienda if self.perfil else 'Sin tienda'})"
# ==========================================
# 🛡️ ESCUDO DE SEÑALES (MÓDULO LOGÍSTICO)
# ==========================================

@receiver(pre_save, sender=PedidoItem)
def capturar_estado_anterior_inventario(sender, instance, **kwargs):
    if instance.pk:
        try:
            instance._estado_previo = PedidoItem.objects.get(pk=instance.pk)
        except PedidoItem.DoesNotExist:
            instance._estado_previo = None
    else:
        instance._estado_previo = None


@receiver(post_save, sender=PedidoItem)
def procesar_ajuste_inventario_dinamico(sender, instance, created, **kwargs):
    with transaction.atomic():
        if created:
            if instance.variante:
                if instance.variante.stock < instance.cantidad:
                    raise ValidationError("Stock insuficiente en la variante seleccionada.")
                instance.variante.stock -= instance.cantidad
                instance.variante.save(update_fields=['stock'])
            else:
                if instance.producto.stock < instance.cantidad:
                    raise ValidationError("Stock insuficiente en el inventario general.")
                instance.producto.stock -= instance.cantidad
                instance.producto.save(update_fields=['stock'])
                
        else:
            previo = getattr(instance, '_estado_previo', None)
            if not previo:
                return

            if previo.variante != instance.variante:
                if previo.variante:
                    previo.variante.stock += previo.cantidad
                    previo.variante.save(update_fields=['stock'])
                else:
                    previo.producto.stock += previo.cantidad
                    previo.producto.save(update_fields=['stock'])

                if instance.variante:
                    if instance.variante.stock < instance.cantidad:
                        raise ValidationError("Stock insuficiente en la nueva variante.")
                    instance.variante.stock -= instance.cantidad
                    instance.variante.save(update_fields=['stock'])
                else:
                    if instance.producto.stock < instance.cantidad:
                        raise ValidationError("Stock insuficiente en el inventario general.")
                    instance.producto.stock -= instance.cantidad
                    instance.producto.save(update_fields=['stock'])
            
            else:
                diferencia = instance.cantidad - previo.cantidad
                if instance.variante:
                    if instance.variante.stock < diferencia:
                        raise ValidationError("La cantidad solicitada supera las existencias de la variante.")
                    instance.variante.stock -= diferencia
                    instance.variante.save(update_fields=['stock'])
                else:
                    if instance.producto.stock < diferencia:
                        raise ValidationError("La cantidad solicitada supera las existencias del inventario general.")
                    instance.producto.stock -= diferencia
                    instance.producto.save(update_fields=['stock'])

        instance.pedido.sincronizar_pedido()


@receiver(post_delete, sender=PedidoItem)
def devolver_inventario_por_eliminacion(sender, instance, **kwargs):
    with transaction.atomic():
        if instance.variante:
            instance.variante.stock += instance.cantidad
            instance.variante.save(update_fields=['stock'])
        else:
            instance.producto.stock += instance.cantidad
            instance.producto.save(update_fields=['stock'])
            
        instance.pedido.sincronizar_pedido()
