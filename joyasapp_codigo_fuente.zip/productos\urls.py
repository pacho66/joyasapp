from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from .views import auth
from .views import catalogo
from .views import admin_catalogo
from .views import carrito
from .views import checkout
from . import views
from productos.views import checkout, pedidos, utilidades
from django.contrib.auth import views as auth_views
from .views import contabilidad
from .views.catalogo import catalogo_tienda
from django.views.generic import TemplateView
from .views.dashboard import crear_empleado_tienda
from .views import checkout 
from productos.views.landing import registrar_evento_embudo
from .views import manual_usuario

urlpatterns = [

    # ===============================
    # 🔓 ENRUTADOR RAÍZ & LANDING SAAS (Con soporte multi-tenant)
    # ===============================
    path('', views.index_saas, name='home'),
    path('', views.index_saas, name='inicio'),
    # ===============================
    # 🔓 AUTENTICACIÓN
    # ===============================
    path('registro/', auth.registro, name='registro'),
    path('login/', auth.iniciar_sesion, name='login'),
    path('logout/', auth.cerrar_sesion, name='logout'),
    path('planes/', views.gestionar_planes, name='gestionar_planes'),
    path('manual-usuario/', manual_usuario, name='manual_usuario'),
     # 📜 Páginas Legales (Habeas Data y Términos SaaS)
    path('terminos-y-condiciones/', TemplateView.as_view(template_name='terminos.html'), name='terminos_y_condiciones'),
    path('politica-de-privacidad/', TemplateView.as_view(template_name='privacidad.html'), name='politica_privacidad'),

    # 🔑 Rutas de recuperación de contraseña
    path('password_reset/', auth_views.PasswordResetView.as_view(template_name='password_reset_form.html'), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(template_name='password_reset_done.html'), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='password_reset_confirm.html'), name='password_reset_confirm'),
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(template_name='password_reset_complete.html'), name='password_reset_complete'),

    # ===============================
    # 🛍️ CATÁLOGO / PRODUCTOS & TALLER
    # ===============================
    path('buscar/', catalogo.buscar_productos, name='buscar_productos'),
    
    # ⚠️ IMPORTANTE: La ruta específica de la calculadora DEBE IR ANTES de 'producto/<int:id>/<slug:slug>/'
    path('producto/<int:producto_id>/calculadora/', views.guardar_variante_fabricacion, name='calculadora_taller'),
    
    # Ruta genérica de detalle del producto en la tienda
    path('producto/<int:id>/<slug:slug>/', catalogo.detalle_producto, name='detalle_producto'),
    
    path('productos/mis-productos/', admin_catalogo.mis_productos, name='mis_productos'),
    path('productos/eliminar/<int:id>', admin_catalogo.eliminar_producto, name='eliminar_producto'),
    path('productos/<int:id>/eliminar-imagen/', admin_catalogo.eliminar_imagen_producto, name='eliminar_imagen_producto'),
    path('imagen-galeria/eliminar/<int:id>/', admin_catalogo.eliminar_imagen_galeria, name='eliminar_imagen_galeria'),
    path('categoria/<int:categoria_id>/', views.productos_por_categoria, name='productos_por_categoria'),
    path('categorias/nueva/', admin_catalogo.crear_categoria, name='crear_categoria'),
    path('categorias/eliminar/<int:categoria_id>/', views.eliminar_categoria, name='eliminar_categoria'),
    path('top-productos/', catalogo.productos_top, name='top_productos'),
    
    # Rutas unificadas para crear y editar usando el mismo controlador
    path('productos/nuevo/', admin_catalogo.guardar_producto_view, name='crear_producto'),
    path('productos/<int:pk>/editar/', admin_catalogo.guardar_producto_view, name='editar_producto'),

    # ===============================
    # 🛠️ MÓDULO DE TALLER Y MANUFACTURA
    # ===============================
    path('fabricacion/', views.fabricacion, name='fabricacion'),
    # ===============================
    # 🛒 CARRITO
    # ===============================
    path('carrito/', carrito.ver_carrito, name='ver_carrito'),
    path('carrito/agregar/<int:producto_id>/', carrito.agregar_al_carrito, name='agregar_al_carrito'),
    path('carrito/eliminar/<int:item_id>/', carrito.eliminar_del_carrito, name='eliminar_del_carrito'),
    path('carrito/aumentar/<int:item_id>/', carrito.aumentar_cantidad, name='aumentar_cantidad'),
    path('carrito/disminuir/<int:item_id>/', carrito.disminuir_cantidad, name='disminuir_cantidad'),

    # ===============================
    # 💳 COMPRAS / PAGOS UNIFICADOS
    # =============================
    path('comprar-whatsapp/', checkout.comprar_whatsapp, name='comprar_whatsapp'),
    path('comprar-directo/<int:producto_id>/', checkout.comprar_whatsapp, name='comprar_directo'),
    path('pagar/', checkout.pagar_pedido, name='pagar_pedido'),
    path('pagar/mercadopago/<uuid:token>/', checkout.pagar_con_mercadopago, name='pagar_con_mercadopago'),
    path('pagar/wompi/<uuid:token>/', checkout.pagar_wompi, name='pagar_wompi'), # <-- Corregido a uuid y renombrado para claridad
    path('pago-exitoso/<uuid:token>/', checkout.pago_exitoso),
    path('confirmar-pago/<uuid:token>/', views.confirmar_pago_publico, name='confirmar_pago_publico'),
    path('confirmar-pago/<int:pedido_id>/', pedidos.confirmar_pago, name='confirmar_pago'),
    path('pago-fallido/<uuid:token>/', checkout.pago_fallido, name='pago_fallido'),

    # ===============================
    # 👑 PLANES / SUSCRIPCIONES SAAS (JOYASAPP)
    # ===============================
    path('planes/pagar/<str:plan_slug>/', checkout.iniciar_pago_suscripcion_wompi, name='pagar_plan'),
    path('api/webhook/wompi/suscripciones/', checkout.webhook_wompi_suscripciones, name='webhook_wompi_planes'),
    # ===============================
    # 💳 WEBHOOKS AUTOMÁTICOS
    # ===============================
    path('webhooks/mercadopago/<uuid:profile_uuid>/', checkout.webhook_mercadopago, name='webhook_mercadopago'),
    path('webhooks/wompi/', checkout.webhook_wompi, name='webhook_wompi'),
    path('webhooks/mercadopago/', checkout.webhook_mercadopago, name='webhook_mercadopago'), 
    
    # ===============================
    # 📦 PEDIDOS
    # ===============================
    path('pedidos/', views.lista_pedidos, name='lista_pedidos'),
    path('pedido/<int:pedido_id>/', views.detalle_pedido, name='detalle_pedido'),
    path('pedido/<int:pedido_id>/pdf/', views.generar_factura, name='pedido_pdf'),
    path('pedido/<int:pedido_id>/abono/', views.registrar_abono, name='registrar_abono'),

    # ===============================
    # 💰 FACTURACIÓN
    # ===============================
    path('factura/<int:pedido_id>/', views.generar_factura, name='generar_factura'),
    path('factura/<uuid:token>/', views.factura_publica, name='factura_publica'),

    # ===============================
    # 💳 COBROS (CORREGIDO)
    # ===============================
    path('cobrar-whatsapp/<int:pedido_id>/', views.cobrar_whatsapp, name='cobrar_whatsapp'),
    path('cobrar/<int:cliente_id>/', views.cobrar_moroso, name='cobrar_cliente'),
    # ===============================
    # 📊 PANEL / SaaS
    # ===============================
    path('dashboard/', views.dashboard, name='dashboard'),
    path('renovar/', views.renovar_manual, name='renovar_manual'),
    path('modificar-banner/', views.modificar_banner, name='modificar_banner'),
    path('estadisticas/', views.estadisticas, name='estadisticas'),
    path('configuracion-negocio/', views.configurar_negocio, name='configurar_negocio'),
    path('ganancias/', views.ganancias, name='ganancias'),
    path('inventario/', admin_catalogo.inventario, name='inventario'),
    path('dashboard/exportar-excel/', views.exportar_excel_dashboard, name='exportar_excel_dashboard'),
    path('crm/', views.panel_crm, name='panel_crm'),
    path('dashboard/empleados/nuevo/', crear_empleado_tienda, name='crear_empleado_tienda'),

    # ===============================
    # 💸 GASTOS
    # ===============================
    # 🏦 Rutas de control financiero unificadas
    path('lista-gastos/', contabilidad.lista_gastos, name='lista_gastos'),
    path('gastos/', contabilidad.gastos, name='gastos'),
    path('lista-gastos/editar/<int:id>/', contabilidad.editar_gasto, name='editar_gasto'),
    path('lista-gastos/duplicar/<int:id>/', contabilidad.duplicar_gasto, name='duplicar_gasto'),
    path('lista-gastos/eliminar/<int:id>/', contabilidad.eliminar_gasto, name='eliminar_gasto'),
    # ===============================
    # 📲 MARKETING
    # ===============================
    path('whatsapp-segmento/', views.whatsapp_segmento, name='whatsapp_segmento'),

    # ===============================
    # 💼 CARTERA
    # ===============================
    path('cartera/', views.cartera_clientes, name='cartera_clientes'),

    # RUTA DE TRACKING DEL EMBUDO 
    path('api/track-embudo/', registrar_evento_embudo, name='track_embudo'),
]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])

